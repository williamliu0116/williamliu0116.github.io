year1 = '2012'
year2 = '2013'
year3 = '2014'
# Get the directory name for data files
import os.path
directory = os.path.dirname(os.path.abspath(__file__)) 

#initialize the aggregators
list_of_number_of_people_all_years=[]

years1=[]
number_of_people1=0

years2=[]
number_of_people2=0

years3=[]
number_of_people3=0

filename = os.path.join(directory, 'All.csv')
datafile = open(filename, 'r')
next(datafile)
for line in datafile:
    years, names, type_of_injury, number = line.split(',')
    # Aggregate based on name1
    number = number.strip()
    if years == year1 and number == '1' or number == '2':
        years1.append(int(years))
        number_of_people1 += int(number)
    
    #Aggregate based on name2
    if years == year2 and number == '1' or number == '2':
        years1.append(int(years))
        number_of_people2 += int(number) 

    if years == year3 and number == '1' or number == '2':
        years1.append(int(years))
        number_of_people3 += int(number) 
        
# Close that year's file
datafile.close()

list_of_number_of_people_all_years.append(number_of_people1)
list_of_number_of_people_all_years.append(number_of_people2)
list_of_number_of_people_all_years.append(number_of_people3)

# Plot on one set of axes.
import matplotlib.pyplot as plt


#bar graph

width = 1/1.5
fig2, ax2 = plt.subplots(1,1)
ax2.bar([2012,2013,2014], list_of_number_of_people_all_years, width, color="blue")
ax2.set_title('NFL concussions during 2012, 2013, and 2014 season')
ax2.set_xticks([2012,2013,2014],[2012,2013,2014])
fig2.show()